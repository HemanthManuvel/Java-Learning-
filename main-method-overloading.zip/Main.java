
public class Main
{
	public static void main(int arg) {
		System.out.println("Hello");
	}
		public static void main(String ar) {
		System.out.println("World");
	}
		public static void main(String[] args) {
		System.out.println("Hello World");
		main(3);
		main("Ski");
	}
}
