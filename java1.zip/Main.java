/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.io.*;
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    
		System.out.print("Roll no : ");
		int r=s.nextInt();
		System.out.print("Name : ");
		String n=s.next();
		System.out.print("CGPA : ");
		int c=s.nextInt();
		System.out.print("Dep ");
		String d=s.next();
		s.nextLine();
		System.out.print("Address : ");
		String a=s.nextLine();
	}
}
